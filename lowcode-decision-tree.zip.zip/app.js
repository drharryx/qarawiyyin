// Decision Tree Data
const decisionTreeData = {
  "title": "Árbol de Decisiones - Enterprise Low Code Platform ITAÚ",
  "subtitle": "Guía de Decisiones para el Negocio - Automatización de Procesos Internos",
  "main_flows": [
    {
      "id": "eligibility",
      "title": "¿Puedo usar Low Code para mi proceso?",
      "icon": "🎯",
      "color": "#2563eb",
      "description": "Validación inicial de elegibilidad",
      "decision_tree": {
        "question": "¿Para quién es esta solución?",
        "options": [
          {
            "answer": "Colaboradores internos ITAÚ",
            "result": "✅ ELEGIBLE",
            "next_question": "¿Qué tipo de proceso automatizarás?",
            "sub_options": [
              {
                "answer": "Procesos de ofimática (Office 365)",
                "result": "✅ APROBADO - Continúa con validaciones",
                "requirements": [
                  "Requiere aprobación Arquitectura Empresarial",
                  "Requiere validación Ciberseguridad",
                  "Debe usar solo Office 365 + Power Platform"
                ]
              },
              {
                "answer": "Procesos con sistemas bancarios",
                "result": "❌ NO PERMITIDO",
                "reason": "No se permite integración con ecosistema Itaú"
              },
              {
                "answer": "Procesos con datos de clientes",
                "result": "⚠️ REQUIERE AUTORIZACIÓN ESPECIAL",
                "requirements": [
                  "Autorización expresa Protección del Dato",
                  "Validación Ciberseguridad",
                  "Validación Seguridad TI"
                ]
              }
            ]
          },
          {
            "answer": "Clientes externos del banco",
            "result": "❌ NO PERMITIDO",
            "reason": "Prohibido crear soluciones para clientes finales"
          },
          {
            "answer": "Usuarios externos a ITAÚ",
            "result": "❌ NO PERMITIDO", 
            "reason": "Prohibido crear aplicaciones para usuarios externos"
          }
        ]
      }
    },
    {
      "id": "data_usage",
      "title": "¿Qué datos puedo usar?",
      "icon": "🗄️",
      "color": "#059669",
      "description": "Clasificación y permisos de datos",
      "decision_tree": {
        "question": "¿Qué tipo de datos necesita tu solución?",
        "options": [
          {
            "answer": "Datos de colaboradores internos",
            "result": "✅ PERMITIDO",
            "conditions": [
              "Solo en bases de datos homologadas",
              "Debe definir ciclo de vida de datos",
              "Separación por capas y usuarios"
            ]
          },
          {
            "answer": "Datos de clientes",
            "result": "⚠️ REQUIERE TRIPLE AUTORIZACIÓN",
            "process": [
              "1. Solicitar autorización Protección del Dato",
              "2. Obtener aprobación Seguridad TI", 
              "3. Validar con Ciberseguridad",
              "4. Documentar justificación de negocio"
            ]
          },
          {
            "answer": "Datos de sistemas de gobierno",
            "result": "❌ NO PERMITIDO",
            "reason": "Plataforma es SOLO CONSUMIDORA, no productora de datos gobierno"
          },
          {
            "answer": "Datos externos al banco",
            "result": "❌ NO PERMITIDO",
            "reason": "No se permiten accesos a repositorios externos"
          }
        ]
      }
    },
    {
      "id": "solution_design",
      "title": "¿Cómo diseño mi solución?",
      "icon": "🏗️",
      "color": "#7c3aed",
      "description": "Proceso de diseño y arquitectura",
      "decision_tree": {
        "question": "¿Tienes las historias de usuario cerradas?",
        "options": [
          {
            "answer": "Sí, están cerradas y definidas",
            "result": "✅ CONTINÚA",
            "next_question": "¿Qué tan completo está tu diseño?",
            "sub_options": [
              {
                "answer": "80% o más completitud",
                "result": "✅ LISTO PARA VALIDACIÓN",
                "next_steps": [
                  "Solicitar tallaje según ATI-PRCD-02",
                  "Presentar a CoE Arquitectura",
                  "Si es necesario: escalamiento a CTO"
                ]
              },
              {
                "answer": "Menos de 80% completitud",
                "result": "⏸️ COMPLETAR DISEÑO",
                "requirements": [
                  "Debe cubrir todos los estándares arquitectónicos",
                  "Diseño modular obligatorio",
                  "Componentes reutilizables"
                ]
              }
            ]
          },
          {
            "answer": "No, aún están en desarrollo",
            "result": "⏸️ DETENER - COMPLETAR HU PRIMERO",
            "reason": "No se puede iniciar diseño sin HU cerradas"
          }
        ]
      }
    },
    {
      "id": "security_controls",
      "title": "¿Qué controles de seguridad necesito?",
      "icon": "🔒",
      "color": "#dc2626",
      "description": "Validación de controles de seguridad",
      "decision_tree": {
        "question": "¿Tu solución transmite datos fuera del banco?",
        "options": [
          {
            "answer": "Sí, transmite datos externos",
            "result": "⚠️ CONTROLES OBLIGATORIOS",
            "requirements": [
              "TLS 1.2 o superior OBLIGATORIO",
              "Protocolos seguros: HTTPS, SMTPs, SFTP",
              "Declarar puertos TCP/UDP en diseño",
              "Análisis de tráfico y monitoreo firewall"
            ]
          },
          {
            "answer": "Solo procesa datos internos",
            "result": "✅ CONTROLES ESTÁNDAR",
            "next_question": "¿En qué ambiente vas a desarrollar?",
            "sub_options": [
              {
                "answer": "Desarrollo y pruebas separados",
                "result": "✅ CORRECTO",
                "additional": [
                  "Separación física/lógica obligatoria",
                  "Solo cambios probados a producción",
                  "Gestión de identidades centralizada"
                ]
              },
              {
                "answer": "Desarrollo directo en producción",
                "result": "❌ NO PERMITIDO",
                "reason": "Debe haber separación de ambientes DEV/QA/PROD"
              }
            ]
          }
        ]
      }
    },
    {
      "id": "deployment",
      "title": "¿Cómo despliego mi solución?",
      "icon": "🚀",
      "color": "#ea580c",
      "description": "Proceso de despliegue y puesta en producción",
      "decision_tree": {
        "question": "¿Tu solución usa conectores Premium?",
        "options": [
          {
            "answer": "Sí, necesito conectores Premium",
            "result": "❌ NO PERMITIDO",
            "reason": "Solo conectores estándar de Office 365/Power Platform"
          },
          {
            "answer": "Solo uso conectores estándar",
            "result": "✅ CONTINÚA",
            "next_question": "¿Tienes aprobación de Transición TI?",
            "sub_options": [
              {
                "answer": "Sí, ticket Jira + certificado ADA",
                "result": "✅ LISTO PARA DESPLIEGUE",
                "final_steps": [
                  "Usar herramienta estándar banco para versionado",
                  "Estructura: mensajes-eventos/workflows/",
                  "Formato kebab-case obligatorio",
                  "Monitoreo post-despliegue"
                ]
              },
              {
                "answer": "No tengo las aprobaciones",
                "result": "⏸️ OBTENER APROBACIONES",
                "required_approvals": [
                  "Ticket Jira Transición TI",
                  "Certificado ADA",
                  "Validación final de arquitectura"
                ]
              }
            ]
          }
        ]
      }
    },
    {
      "id": "monitoring_maintenance",
      "title": "¿Cómo monitoreo y mantengo mi solución?",
      "icon": "📊",
      "color": "#0891b2",
      "description": "Operación y mantenimiento post-despliegue",
      "decision_tree": {
        "question": "¿Tienes plan de monitoreo definido?",
        "options": [
          {
            "answer": "Sí, plan completo",
            "result": "✅ OPERACIÓN CORRECTA",
            "operational_requirements": [
              "Monitoreo herramientas Power Automate",
              "Roles productivos con acceso a monitoreo",
              "Plan de respuesta a incidentes",
              "Dependencia del soporte proveedor considerada"
            ]
          },
          {
            "answer": "No tengo plan de monitoreo",
            "result": "⚠️ CREAR PLAN OBLIGATORIO",
            "requirements": [
              "Definir métricas de negocio",
              "Establecer alertas automáticas",
              "Capacitar al equipo operativo",
              "Documentar procedimientos de soporte"
            ]
          }
        ]
      }
    }
  ]
};

// Application Controller
class DecisionTreeApp {
  constructor() {
    this.currentFlow = null;
    this.currentPath = [];
    this.breadcrumbPath = [];
    this.decisionHistory = [];
    this.currentNode = null;
    
    this.init();
  }

  init() {
    this.bindEvents();
    this.showView('home');
  }

  bindEvents() {
    // Flow card clicks
    document.querySelectorAll('.flow-card').forEach(card => {
      card.addEventListener('click', (e) => {
        const flowId = e.currentTarget.dataset.flow;
        this.startFlow(flowId);
      });
    });

    // Navigation buttons
    const homeBtn = document.getElementById('home-btn');
    const restartBtn = document.getElementById('restart-btn');
    const backToFlowBtn = document.getElementById('back-to-flow');
    const homeFromResultBtn = document.getElementById('home-from-result');
    const exportBtn = document.getElementById('export-result');

    if (homeBtn) {
      homeBtn.addEventListener('click', () => {
        this.showView('home');
        this.resetFlow();
      });
    }

    if (restartBtn) {
      restartBtn.addEventListener('click', () => {
        this.restartCurrentFlow();
      });
    }

    if (backToFlowBtn) {
      backToFlowBtn.addEventListener('click', () => {
        this.showView('decision');
      });
    }

    if (homeFromResultBtn) {
      homeFromResultBtn.addEventListener('click', () => {
        this.showView('home');
        this.resetFlow();
      });
    }

    if (exportBtn) {
      exportBtn.addEventListener('click', () => {
        this.exportResult();
      });
    }

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.showView('home');
        this.resetFlow();
      }
    });
  }

  showView(viewName) {
    // Hide all views
    document.querySelectorAll('.view').forEach(view => {
      view.classList.remove('active');
    });

    // Show selected view
    const targetView = document.getElementById(`${viewName}-view`);
    if (targetView) {
      targetView.classList.add('active');
      targetView.classList.add('fade-in');
      
      // Remove animation class after animation completes
      setTimeout(() => {
        targetView.classList.remove('fade-in');
      }, 300);
    }
  }

  startFlow(flowId) {
    const flow = decisionTreeData.main_flows.find(f => f.id === flowId);
    if (!flow) return;

    this.currentFlow = flow;
    this.currentPath = [];
    this.breadcrumbPath = [flow.title];
    this.decisionHistory = [];
    this.currentNode = flow.decision_tree;

    this.showView('decision');
    this.renderFlowHeader();
    this.renderDecisionNode(this.currentNode);
    this.updateBreadcrumb();
    this.updateInfoPanel('Selecciona una opción para continuar con el flujo de decisiones.');
  }

  renderFlowHeader() {
    const titleEl = document.getElementById('flow-title');
    const descEl = document.getElementById('flow-description');
    
    if (titleEl) titleEl.textContent = this.currentFlow.title;
    if (descEl) descEl.textContent = this.currentFlow.description;
  }

  renderDecisionNode(node) {
    const container = document.getElementById('tree-content');
    if (!container) return;

    container.innerHTML = '';
    container.classList.add('slide-in');

    // Create question node
    const questionDiv = document.createElement('div');
    questionDiv.className = 'question-node';

    const questionText = document.createElement('div');
    questionText.className = 'question-text';
    questionText.textContent = node.question;

    const optionsGrid = document.createElement('div');
    optionsGrid.className = 'options-grid';

    // Create option buttons
    node.options.forEach((option, index) => {
      const optionBtn = document.createElement('button');
      optionBtn.className = 'option-btn';
      optionBtn.textContent = option.answer;
      optionBtn.setAttribute('data-option-index', index);

      optionBtn.addEventListener('click', () => {
        this.handleOptionClick(option, node.question);
      });

      optionsGrid.appendChild(optionBtn);
    });

    questionDiv.appendChild(questionText);
    questionDiv.appendChild(optionsGrid);
    container.appendChild(questionDiv);

    // Remove animation class after animation completes
    setTimeout(() => {
      container.classList.remove('slide-in');
    }, 300);
  }

  handleOptionClick(option, currentQuestion) {
    console.log('Option clicked:', option);

    // Record decision in history
    this.decisionHistory.push({
      question: currentQuestion,
      answer: option.answer,
      result: option.result
    });

    // Update breadcrumb
    this.breadcrumbPath.push(option.answer);
    this.updateBreadcrumb();

    // Update info panel with option details
    this.updateInfoPanel(this.formatOptionInfo(option));

    // Check if this option has sub-options (next level)
    if (option.sub_options && option.sub_options.length > 0) {
      // Create a new node for sub-options
      const subNode = {
        question: option.next_question || "Selecciona la opción más específica:",
        options: option.sub_options
      };
      this.currentNode = subNode;
      // Render sub-question after a brief delay for UX
      setTimeout(() => {
        this.renderDecisionNode(subNode);
      }, 500);
    } else {
      // This is a final result - show it
      setTimeout(() => {
        this.showResult(option);
      }, 500);
    }
  }

  showResult(option) {
    this.showView('result');
    this.renderResult(option);
  }

  renderResult(option) {
    const headerEl = document.getElementById('result-header');
    const contentEl = document.getElementById('result-content');

    if (!headerEl || !contentEl) return;

    // Determine result type and styling
    const resultType = this.getResultType(option.result);
    const resultIcon = this.getResultIcon(option.result);

    // Clear previous content
    headerEl.innerHTML = '';
    contentEl.innerHTML = '';

    // Create result header
    const iconDiv = document.createElement('div');
    iconDiv.className = 'result-icon';
    iconDiv.textContent = resultIcon;

    const titleDiv = document.createElement('h2');
    titleDiv.className = `result-title ${resultType}`;
    titleDiv.textContent = option.result;

    headerEl.appendChild(iconDiv);
    headerEl.appendChild(titleDiv);

    // Create result content sections
    const sections = [];

    // Add reason if exists
    if (option.reason) {
      sections.push({
        title: '📋 Motivo',
        content: `<div class="result-reason"><strong>Razón:</strong> ${option.reason}</div>`,
        type: 'html'
      });
    }

    // Add requirements if exists
    if (option.requirements) {
      sections.push({
        title: '✅ Requisitos',
        content: option.requirements,
        type: 'list'
      });
    }

    // Add conditions if exists
    if (option.conditions) {
      sections.push({
        title: '📋 Condiciones',
        content: option.conditions,
        type: 'list'
      });
    }

    // Add process steps if exists
    if (option.process) {
      sections.push({
        title: '🔄 Proceso a Seguir',
        content: option.process,
        type: 'list'
      });
    }

    // Add next steps if exists
    if (option.next_steps) {
      sections.push({
        title: '➡️ Próximos Pasos',
        content: option.next_steps,
        type: 'list'
      });
    }

    // Add final steps if exists
    if (option.final_steps) {
      sections.push({
        title: '🎯 Pasos Finales',
        content: option.final_steps,
        type: 'list'
      });
    }

    // Add additional info if exists
    if (option.additional) {
      sections.push({
        title: 'ℹ️ Información Adicional',
        content: option.additional,
        type: 'list'
      });
    }

    // Add operational requirements if exists
    if (option.operational_requirements) {
      sections.push({
        title: '⚙️ Requisitos Operacionales',
        content: option.operational_requirements,
        type: 'list'
      });
    }

    // Add required approvals if exists
    if (option.required_approvals) {
      sections.push({
        title: '✍️ Aprobaciones Requeridas',
        content: option.required_approvals,
        type: 'list'
      });
    }

    // Render sections
    sections.forEach(section => {
      const sectionDiv = document.createElement('div');
      sectionDiv.className = 'result-section';

      const titleEl = document.createElement('h4');
      titleEl.textContent = section.title;
      sectionDiv.appendChild(titleEl);

      if (section.type === 'list') {
        const listEl = document.createElement('ul');
        listEl.className = 'result-list';
        section.content.forEach(item => {
          const li = document.createElement('li');
          li.textContent = item;
          listEl.appendChild(li);
        });
        sectionDiv.appendChild(listEl);
      } else if (section.type === 'html') {
        sectionDiv.innerHTML += section.content;
      }

      contentEl.appendChild(sectionDiv);
    });

    // Add decision path summary
    if (this.decisionHistory.length > 0) {
      const pathSection = document.createElement('div');
      pathSection.className = 'result-section';
      
      const pathTitle = document.createElement('h4');
      pathTitle.textContent = '🗺️ Camino de Decisión';
      pathSection.appendChild(pathTitle);
      
      const pathList = document.createElement('ul');
      pathList.className = 'result-list';
      this.decisionHistory.forEach((decision, index) => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>Paso ${index + 1}:</strong> ${decision.question}<br>→ <em>${decision.answer}</em>`;
        pathList.appendChild(li);
      });
      pathSection.appendChild(pathList);
      contentEl.appendChild(pathSection);
    }
  }

  getResultType(result) {
    if (result.includes('✅') || result.includes('APROBADO') || result.includes('PERMITIDO') || result.includes('CORRECTO') || result.includes('LISTO')) {
      return 'approved';
    } else if (result.includes('❌') || result.includes('NO PERMITIDO') || result.includes('RECHAZADO')) {
      return 'rejected';
    } else if (result.includes('⚠️') || result.includes('REQUIERE') || result.includes('OBLIGATORIO')) {
      return 'action-required';
    } else if (result.includes('⏸️') || result.includes('PAUSAR') || result.includes('DETENER') || result.includes('COMPLETAR')) {
      return 'paused';
    }
    return 'approved';
  }

  getResultIcon(result) {
    if (result.includes('✅')) return '✅';
    if (result.includes('❌')) return '❌';
    if (result.includes('⚠️')) return '⚠️';
    if (result.includes('⏸️')) return '⏸️';
    return '📋';
  }

  formatOptionInfo(option) {
    let info = `<p><strong>Opción seleccionada:</strong> ${option.answer}</p>`;
    
    if (option.result) {
      info += `<p><strong>Resultado:</strong> ${option.result}</p>`;
    }

    if (option.reason) {
      info += `<p><strong>Motivo:</strong> ${option.reason}</p>`;
    }

    if (option.requirements && option.requirements.length > 0) {
      info += '<p><strong>Requisitos:</strong></p><ul>';
      option.requirements.forEach(req => {
        info += `<li>${req}</li>`;
      });
      info += '</ul>';
    }

    if (option.conditions && option.conditions.length > 0) {
      info += '<p><strong>Condiciones:</strong></p><ul>';
      option.conditions.forEach(cond => {
        info += `<li>${cond}</li>`;
      });
      info += '</ul>';
    }

    if (option.next_question) {
      info += `<p><strong>Próxima pregunta:</strong> ${option.next_question}</p>`;
    } else if (option.sub_options && option.sub_options.length > 0) {
      info += '<p><strong>Opciones disponibles:</strong> Se mostrará la siguiente pregunta.</p>';
    } else {
      info += '<p><strong>Estado:</strong> Esta es una decisión final. Se mostrará el resultado completo.</p>';
    }

    return info;
  }

  updateBreadcrumb() {
    const container = document.getElementById('breadcrumb-path');
    if (!container) return;

    container.innerHTML = '';

    this.breadcrumbPath.forEach((item, index) => {
      if (index > 0) {
        const separator = document.createElement('span');
        separator.className = 'breadcrumb-separator';
        separator.textContent = '→';
        container.appendChild(separator);
      }

      const breadcrumbItem = document.createElement('span');
      breadcrumbItem.className = index === this.breadcrumbPath.length - 1 ? 'breadcrumb-current' : 'breadcrumb-item';
      breadcrumbItem.textContent = item.length > 50 ? item.substring(0, 50) + '...' : item;
      breadcrumbItem.title = item; // Full text on hover
      container.appendChild(breadcrumbItem);
    });
  }

  updateInfoPanel(content) {
    const panelContent = document.getElementById('panel-content');
    if (!panelContent) return;

    if (typeof content === 'string') {
      panelContent.innerHTML = content;
    } else {
      panelContent.innerHTML = '<p>Información no disponible</p>';
    }
  }

  restartCurrentFlow() {
    if (this.currentFlow) {
      this.startFlow(this.currentFlow.id);
    }
  }

  resetFlow() {
    this.currentFlow = null;
    this.currentPath = [];
    this.breadcrumbPath = [];
    this.decisionHistory = [];
    this.currentNode = null;
  }

  exportResult() {
    if (this.decisionHistory.length === 0) {
      alert('No hay decisiones para exportar');
      return;
    }

    // Create export content
    let exportContent = `RESUMEN DE DECISIONES - ITAÚ LOW CODE PLATFORM\n`;
    exportContent += `=====================================================\n\n`;
    exportContent += `Flujo: ${this.currentFlow.title}\n`;
    exportContent += `Fecha: ${new Date().toLocaleString('es-ES')}\n\n`;
    
    exportContent += `CAMINO DE DECISIÓN:\n`;
    exportContent += `------------------\n`;
    this.decisionHistory.forEach((decision, index) => {
      exportContent += `${index + 1}. ${decision.question}\n`;
      exportContent += `   → ${decision.answer}\n`;
      if (decision.result) {
        exportContent += `   Resultado: ${decision.result}\n`;
      }
      exportContent += `\n`;
    });

    exportContent += `RESULTADO FINAL:\n`;
    exportContent += `---------------\n`;
    const resultElement = document.querySelector('.result-title');
    if (resultElement) {
      exportContent += resultElement.textContent + '\n\n';
    }

    // Add additional details from result content
    const resultSections = document.querySelectorAll('.result-section');
    resultSections.forEach(section => {
      const title = section.querySelector('h4');
      if (title && !title.textContent.includes('Camino de Decisión')) {
        exportContent += `${title.textContent}\n`;
        const list = section.querySelector('.result-list');
        if (list) {
          const items = list.querySelectorAll('li');
          items.forEach(item => {
            exportContent += `• ${item.textContent}\n`;
          });
        }
        exportContent += '\n';
      }
    });

    exportContent += `\nContactos de soporte:\n`;
    exportContent += `• Arquitectura Empresarial: arquitectura.ea@itau.com\n`;
    exportContent += `• Ciberseguridad: ciberseguridad@itau.com\n`;
    exportContent += `• Protección del Dato: proteccion.datos@itau.com\n`;

    // Create and download file
    const blob = new Blob([exportContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resumen-decision-lowcode-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    // Show confirmation
    alert('Resumen exportado exitosamente');
  }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const app = new DecisionTreeApp();
  
  // Make app globally accessible for debugging
  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    window.decisionApp = app;
    console.log('🎯 Árbol de Decisiones ITAÚ cargado');
    console.log('📋 Usa decisionApp para acceso programático');
  }

  // Add keyboard accessibility
  document.addEventListener('keydown', (e) => {
    // Allow Enter key to click focused elements
    if (e.key === 'Enter') {
      const focused = document.activeElement;
      if (focused && (focused.classList.contains('flow-card') || focused.classList.contains('option-btn'))) {
        focused.click();
      }
    }
  });

  // Make flow cards keyboard accessible
  document.querySelectorAll('.flow-card').forEach(card => {
    card.setAttribute('tabindex', '0');
    card.setAttribute('role', 'button');
    card.setAttribute('aria-label', `Iniciar flujo: ${card.querySelector('h3').textContent}`);
  });

  // Add click handlers for better UX feedback
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('option-btn')) {
      // Add visual feedback for option selection
      e.target.style.backgroundColor = 'var(--color-primary)';
      e.target.style.color = 'var(--color-btn-primary-text)';
      e.target.style.transform = 'scale(0.98)';
      
      setTimeout(() => {
        e.target.style.backgroundColor = '';
        e.target.style.color = '';
        e.target.style.transform = '';
      }, 200);
    }
  });
});