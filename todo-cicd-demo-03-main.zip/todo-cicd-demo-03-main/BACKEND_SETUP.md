# Scripts de Configuración del Backend de Terraform

Este directorio contiene scripts para automatizar la configuración y limpieza del backend de Terraform en AWS.

## Scripts Disponibles

### 🚀 setup-terraform-backend.sh / setup-terraform-backend.ps1
Configura automáticamente el backend de Terraform creando:
- Bucket S3 para almacenar el estado de Terraform
- Tabla DynamoDB para el bloqueo del estado
- Configuración de seguridad (encriptación, versionado, bloqueo de acceso público)

### 🗑️ cleanup-terraform-backend.sh
Elimina todos los recursos del backend de Terraform (usar con precaución).

## Uso

### En Linux/macOS:
```bash
# Configurar backend
./setup-terraform-backend.sh

# Limpiar backend (CUIDADO: elimina todo)
./cleanup-terraform-backend.sh
```

### En Windows (PowerShell):
```powershell
# Configurar backend
.\setup-terraform-backend.ps1

# Parámetros opcionales
.\setup-terraform-backend.ps1 -ProjectName "mi-proyecto" -AWSRegion "us-west-2"
```

## Prerequisitos

1. **AWS CLI instalado y configurado**
   ```bash
   aws configure
   ```

2. **Credenciales AWS con permisos para:**
   - Crear/eliminar buckets S3
   - Crear/eliminar tablas DynamoDB
   - Configurar políticas de bucket

## ¿Qué hacen los scripts?

### Setup Script:
1. ✅ Verifica que AWS CLI esté instalado y configurado
2. 🪣 Crea un bucket S3 único con timestamp
3. 🔄 Habilita versionado en el bucket
4. 🔒 Configura encriptación AES256
5. 🛡️ Bloquea acceso público al bucket
6. 🗄️ Crea tabla DynamoDB para bloqueo de estado
7. 📝 Actualiza `main.tf` con el nuevo bucket
8. 📋 Muestra información para configurar GitLab CI/CD

### Cleanup Script:
1. ⚠️ Pide confirmación (debes escribir 'ELIMINAR')
2. 🗑️ Elimina todo el contenido del bucket S3
3. 🗑️ Elimina el bucket S3
4. 🗑️ Elimina la tabla DynamoDB

## Variables de GitLab CI/CD

Después de ejecutar el script de setup, configura estas variables en GitLab:

```
AWS_ACCESS_KEY_ID: tu_access_key_id
AWS_SECRET_ACCESS_KEY: tu_secret_access_key
```

## Estructura de Archivos Generados

```
backend/
├── s3://terraform-state-openwebui-[timestamp]/
│   └── openwebui/infra/terraform.tfstate
└── DynamoDB: terraform-state-lock
```

## Seguridad

- ✅ Bucket con acceso público bloqueado
- ✅ Encriptación habilitada
- ✅ Versionado habilitado
- ✅ Tabla DynamoDB para prevenir corrupción del estado

## Costos Estimados

- **Bucket S3**: ~$0.023/GB/mes
- **DynamoDB**: ~$0.25/mes (1 RCU + 1 WCU)
- **Total**: < $1/mes para uso típico
