# OpenWebUI Infrastructura

Este proyecto contiene la infraestructura como código para desplegar OpenWebUI en AWS usando Terraform y GitLab CI/CD.

## 🚀 Inicio Rápido (Para Fork)

### 1. Hacer Fork del Proyecto
- Haz fork de este proyecto en GitLab
- Clona tu fork localmente

### 2. Configurar Variables de AWS en GitLab
Ve a **Settings** → **CI/CD** → **Variables** y agrega:

| Variable | Valor | Protected | Masked |
|----------|-------|-----------|---------|
| `AWS_ACCESS_KEY_ID` | Tu Access Key | ✅ | ✅ |
| `AWS_SECRET_ACCESS_KEY` | Tu Secret Key | ✅ | ✅ |

### 3. Opciones de Backend

#### Opción A: Usar Backend Existente (Más Rápido)
- Simplemente haz push y el pipeline usará el backend preconfigurado
- ⚠️ **Nota**: Compartirás el estado con otros usuarios

#### Opción B: Crear Tu Propio Backend (Recomendado)
```bash
# Ejecutar script de setup
./setup-terraform-backend.sh

# Actualizar variable en GitLab CI/CD Variables:
# TF_STATE_BUCKET: el-nuevo-bucket-generado
```

### 4. Ejecutar Pipeline
- Haz push a la rama `main`
- Ve a **CI/CD** → **Pipelines**
- Ejecuta manualmente el job `apply` cuando esté listo

## 📋 Variables de Configuración

### Requeridas (debes configurar):
- `AWS_ACCESS_KEY_ID`: Tu Access Key de AWS
- `AWS_SECRET_ACCESS_KEY`: Tu Secret Key de AWS

### Opcionales (predefinidas):
- `AWS_DEFAULT_REGION`: us-east-1
- `TF_STATE_KEY`: openwebui/infra/terraform.tfstate
- `TF_DYNAMODB_TABLE`: terraform-state-lock
- `TF_STATE_BUCKET`: terraform-state-openwebui-1755137612

## 🏗️ Arquitectura

- **VPC** con subredes públicas y privadas
- **ECS Fargate** para ejecutar el contenedor OpenWebUI
- **Application Load Balancer** para distribución de tráfico
- **EFS** para almacenamiento persistente
- **CloudWatch** para logs

## 📂 Estructura del Proyecto

```
.
├── main.tf           # Configuración principal de Terraform
├── variables.tf      # Variables de configuración
├── network.tf        # Configuración de red (VPC, subnets, security groups)
├── ecs.tf           # Configuración de ECS y ALB
├── efs.tf           # Configuración de EFS
├── outputs.tf       # Outputs de Terraform
├── .gitlab-ci.yml   # Pipeline de CI/CD
├── setup-terraform-backend.sh    # Script para configurar backend
├── setup-terraform-backend.ps1   # Script PowerShell para Windows
└── BACKEND_SETUP.md # Documentación de scripts
```

## 🔄 Pipeline de CI/CD

El pipeline incluye las siguientes etapas:

1. **Validate**: Valida la sintaxis de Terraform (automático)
2. **Plan**: Genera el plan de ejecución (automático)
3. **Apply**: Aplica los cambios (manual)
4. **Destroy**: Destruye la infraestructura (manual)

## 💰 Costos Estimados

- **ECS Fargate**: ~$30-50/mes (1 vCPU, 2GB RAM)
- **Application Load Balancer**: ~$16/mes
- **NAT Gateway**: ~$32/mes
- **EFS**: ~$0.30/GB/mes

**Total estimado**: ~$80-100/mes

## 🧹 Limpieza

Para destruir toda la infraestructura:
1. Ve a GitLab CI/CD → Pipelines
2. Ejecuta manualmente el job "destroy"

## ❓ Troubleshooting

### Error: "AccessDenied" en S3/DynamoDB
- Verifica que las credenciales AWS estén correctamente configuradas
- Asegúrate de que tu usuario IAM tenga permisos para S3 y DynamoDB

### Error: "Backend initialization failed"
- Ejecuta `./setup-terraform-backend.sh` para crear tu propio backend
- Actualiza la variable `TF_STATE_BUCKET` en GitLab

### Pipeline no se ejecuta
- Verifica que las variables `AWS_ACCESS_KEY_ID` y `AWS_SECRET_ACCESS_KEY` estén configuradas
- Asegúrate de estar en la rama `main` o `develop`
