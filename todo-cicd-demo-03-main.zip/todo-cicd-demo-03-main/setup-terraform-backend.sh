#!/bin/bash

# Script para configurar el backend de Terraform en AWS
# Crea un bucket S3 y una tabla DynamoDB para el estado de Terraform

set -e  # Salir si cualquier comando falla

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuración
PROJECT_NAME="openwebui"
AWS_REGION="us-east-1"
BUCKET_SUFFIX=$(date +%s)
BUCKET_NAME="terraform-state-${PROJECT_NAME}-${BUCKET_SUFFIX}"
DYNAMODB_TABLE="terraform-state-lock"

echo -e "${BLUE}🚀 Configurando backend de Terraform para OpenWebUI${NC}"
echo -e "${BLUE}=================================================${NC}"

# Verificar que AWS CLI esté instalado y configurado
echo -e "${YELLOW}📋 Verificando prerequisitos...${NC}"

if ! command -v aws &> /dev/null; then
    echo -e "${RED}❌ AWS CLI no está instalado${NC}"
    echo -e "${YELLOW}💡 Por favor instala AWS CLI: https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html${NC}"
    exit 1
fi

# Verificar credenciales de AWS
if ! aws sts get-caller-identity &> /dev/null; then
    echo -e "${RED}❌ AWS CLI no está configurado correctamente${NC}"
    echo -e "${YELLOW}💡 Por favor ejecuta: aws configure${NC}"
    exit 1
fi

echo -e "${GREEN}✅ AWS CLI configurado correctamente${NC}"

# Obtener información de la cuenta
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo -e "${BLUE}📊 Cuenta AWS: ${ACCOUNT_ID}${NC}"
echo -e "${BLUE}📍 Región: ${AWS_REGION}${NC}"

# Crear bucket S3
echo -e "${YELLOW}🪣 Creando bucket S3: ${BUCKET_NAME}${NC}"

if aws s3 mb "s3://${BUCKET_NAME}" --region "${AWS_REGION}" 2>/dev/null; then
    echo -e "${GREEN}✅ Bucket S3 creado exitosamente${NC}"
else
    echo -e "${RED}❌ Error creando bucket S3${NC}"
    exit 1
fi

# Habilitar versionado en el bucket
echo -e "${YELLOW}🔄 Habilitando versionado en el bucket...${NC}"
aws s3api put-bucket-versioning \
    --bucket "${BUCKET_NAME}" \
    --versioning-configuration Status=Enabled

# Habilitar encriptación en el bucket
echo -e "${YELLOW}🔒 Habilitando encriptación en el bucket...${NC}"
aws s3api put-bucket-encryption \
    --bucket "${BUCKET_NAME}" \
    --server-side-encryption-configuration '{
        "Rules": [
            {
                "ApplyServerSideEncryptionByDefault": {
                    "SSEAlgorithm": "AES256"
                }
            }
        ]
    }'

# Bloquear acceso público
echo -e "${YELLOW}🛡️  Bloqueando acceso público al bucket...${NC}"
aws s3api put-public-access-block \
    --bucket "${BUCKET_NAME}" \
    --public-access-block-configuration \
    BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

# Crear tabla DynamoDB
echo -e "${YELLOW}🗄️  Creando tabla DynamoDB: ${DYNAMODB_TABLE}${NC}"

if aws dynamodb create-table \
    --table-name "${DYNAMODB_TABLE}" \
    --attribute-definitions AttributeName=LockID,AttributeType=S \
    --key-schema AttributeName=LockID,KeyType=HASH \
    --provisioned-throughput ReadCapacityUnits=1,WriteCapacityUnits=1 \
    --region "${AWS_REGION}" &> /dev/null; then
    echo -e "${GREEN}✅ Tabla DynamoDB creada exitosamente${NC}"
else
    echo -e "${RED}❌ Error creando tabla DynamoDB (puede que ya exista)${NC}"
fi

# Esperar a que la tabla esté activa
echo -e "${YELLOW}⏳ Esperando a que la tabla DynamoDB esté activa...${NC}"
aws dynamodb wait table-exists --table-name "${DYNAMODB_TABLE}" --region "${AWS_REGION}"

# Actualizar main.tf con el nombre del bucket
echo -e "${YELLOW}📝 Actualizando main.tf con el nuevo bucket...${NC}"

if [ -f "main.tf" ]; then
    # Crear backup del archivo original
    cp main.tf main.tf.backup
    
    # Actualizar el nombre del bucket en main.tf
    sed -i.tmp "s/bucket[[:space:]]*=[[:space:]]*\"[^\"]*\"/bucket         = \"${BUCKET_NAME}\"/g" main.tf
    rm -f main.tf.tmp
    
    echo -e "${GREEN}✅ main.tf actualizado${NC}"
else
    echo -e "${YELLOW}⚠️  Archivo main.tf no encontrado en el directorio actual${NC}"
    echo -e "${YELLOW}💡 Por favor actualiza manualmente el nombre del bucket en main.tf${NC}"
fi

# Mostrar resumen
echo -e "${BLUE}=================================================${NC}"
echo -e "${GREEN}🎉 ¡Configuración completada exitosamente!${NC}"
echo -e "${BLUE}=================================================${NC}"
echo -e "${YELLOW}📋 Información del backend:${NC}"
echo -e "   🪣 Bucket S3: ${BUCKET_NAME}"
echo -e "   🗄️  Tabla DynamoDB: ${DYNAMODB_TABLE}"
echo -e "   📍 Región: ${AWS_REGION}"
echo -e ""
echo -e "${YELLOW}📝 Variables para GitLab CI/CD:${NC}"
echo -e "   TF_STATE_BUCKET: ${BUCKET_NAME}"
echo -e "   TF_STATE_KEY: openwebui/infra/terraform.tfstate"
echo -e "   TF_DYNAMODB_TABLE: ${DYNAMODB_TABLE}"
echo -e "   AWS_DEFAULT_REGION: ${AWS_REGION}"
echo -e ""
echo -e "${YELLOW}🔐 No olvides configurar en GitLab CI/CD Variables:${NC}"
echo -e "   AWS_ACCESS_KEY_ID: tu_access_key"
echo -e "   AWS_SECRET_ACCESS_KEY: tu_secret_key"
echo -e ""
echo -e "${GREEN}✨ Ya puedes ejecutar: terraform init${NC}"
