#!/bin/bash

# Script para limpiar recursos del backend de Terraform
# ADVERTENCIA: Esto eliminará el bucket S3 y la tabla DynamoDB

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuración
AWS_REGION="us-east-1"
DYNAMODB_TABLE="terraform-state-lock"

echo -e "${RED}🗑️  Script de limpieza del backend de Terraform${NC}"
echo -e "${RED}===============================================${NC}"
echo -e "${YELLOW}⚠️  ADVERTENCIA: Este script eliminará:${NC}"
echo -e "${YELLOW}   - Bucket S3 del estado de Terraform${NC}"
echo -e "${YELLOW}   - Tabla DynamoDB de bloqueo${NC}"
echo -e "${YELLOW}   - Todos los archivos de estado almacenados${NC}"

# Pedir confirmación
read -p "¿Estás seguro de que quieres continuar? (escribe 'ELIMINAR' para confirmar): " confirmation

if [ "$confirmation" != "ELIMINAR" ]; then
    echo -e "${GREEN}✅ Operación cancelada${NC}"
    exit 0
fi

# Buscar bucket que coincida con el patrón
echo -e "${YELLOW}🔍 Buscando bucket de Terraform...${NC}"

BUCKET_NAME=""
if [ -f "main.tf" ]; then
    BUCKET_NAME=$(grep -o 'bucket[[:space:]]*=[[:space:]]*"[^"]*"' main.tf | cut -d'"' -f2)
fi

if [ -z "$BUCKET_NAME" ]; then
    echo -e "${YELLOW}⚠️  No se pudo determinar el bucket desde main.tf${NC}"
    echo -e "${YELLOW}📝 Por favor ingresa el nombre del bucket manualmente:${NC}"
    read -p "Nombre del bucket S3: " BUCKET_NAME
fi

if [ -z "$BUCKET_NAME" ]; then
    echo -e "${RED}❌ Nombre de bucket requerido${NC}"
    exit 1
fi

echo -e "${BLUE}📊 Configuración:${NC}"
echo -e "   🪣 Bucket S3: ${BUCKET_NAME}"
echo -e "   🗄️  Tabla DynamoDB: ${DYNAMODB_TABLE}"
echo -e "   📍 Región: ${AWS_REGION}"

# Verificar que el bucket existe
if aws s3 ls "s3://${BUCKET_NAME}" &> /dev/null; then
    echo -e "${YELLOW}🗑️  Eliminando contenido del bucket S3...${NC}"
    
    # Eliminar todas las versiones de objetos
    aws s3api delete-objects \
        --bucket "${BUCKET_NAME}" \
        --delete "$(aws s3api list-object-versions \
            --bucket "${BUCKET_NAME}" \
            --output json \
            --query '{Objects: Versions[].{Key:Key,VersionId:VersionId}}')" 2>/dev/null || true
    
    # Eliminar marcadores de borrado
    aws s3api delete-objects \
        --bucket "${BUCKET_NAME}" \
        --delete "$(aws s3api list-object-versions \
            --bucket "${BUCKET_NAME}" \
            --output json \
            --query '{Objects: DeleteMarkers[].{Key:Key,VersionId:VersionId}}')" 2>/dev/null || true
    
    # Eliminar bucket
    echo -e "${YELLOW}🗑️  Eliminando bucket S3...${NC}"
    if aws s3 rb "s3://${BUCKET_NAME}" --force; then
        echo -e "${GREEN}✅ Bucket S3 eliminado exitosamente${NC}"
    else
        echo -e "${RED}❌ Error eliminando bucket S3${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  Bucket S3 no encontrado o ya eliminado${NC}"
fi

# Eliminar tabla DynamoDB
echo -e "${YELLOW}🗑️  Eliminando tabla DynamoDB...${NC}"
if aws dynamodb delete-table --table-name "${DYNAMODB_TABLE}" --region "${AWS_REGION}" &> /dev/null; then
    echo -e "${GREEN}✅ Tabla DynamoDB eliminada exitosamente${NC}"
    
    # Esperar a que la tabla se elimine completamente
    echo -e "${YELLOW}⏳ Esperando a que la tabla se elimine completamente...${NC}"
    aws dynamodb wait table-not-exists --table-name "${DYNAMODB_TABLE}" --region "${AWS_REGION}"
else
    echo -e "${YELLOW}⚠️  Tabla DynamoDB no encontrada o ya eliminada${NC}"
fi

echo -e "${BLUE}=================================================${NC}"
echo -e "${GREEN}🎉 ¡Limpieza completada!${NC}"
echo -e "${BLUE}=================================================${NC}"
echo -e "${YELLOW}📋 Recursos eliminados:${NC}"
echo -e "   🪣 Bucket S3: ${BUCKET_NAME}"
echo -e "   🗄️  Tabla DynamoDB: ${DYNAMODB_TABLE}"
echo -e ""
echo -e "${YELLOW}💡 Para volver a configurar el backend, ejecuta:${NC}"
echo -e "   ./setup-terraform-backend.sh"
