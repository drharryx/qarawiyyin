# Script para configurar el backend de Terraform en AWS
# Crea un bucket S3 y una tabla DynamoDB para el estado de Terraform

param(
    [string]$ProjectName = "openwebui",
    [string]$AWSRegion = "us-east-1"
)

# Configuración de colores para output
$Colors = @{
    Red = "Red"
    Green = "Green"
    Yellow = "Yellow"
    Blue = "Cyan"
    White = "White"
}

function Write-ColoredOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Colors[$Color]
}

# Configuración
$BucketSuffix = [int][double]::Parse((Get-Date -UFormat %s))
$BucketName = "terraform-state-$ProjectName-$BucketSuffix"
$DynamoDBTable = "terraform-state-lock"

Write-ColoredOutput "🚀 Configurando backend de Terraform para OpenWebUI" "Blue"
Write-ColoredOutput "=================================================" "Blue"

# Verificar que AWS CLI esté instalado
Write-ColoredOutput "📋 Verificando prerequisitos..." "Yellow"

try {
    $null = Get-Command aws -ErrorAction Stop
    Write-ColoredOutput "✅ AWS CLI encontrado" "Green"
} catch {
    Write-ColoredOutput "❌ AWS CLI no está instalado" "Red"
    Write-ColoredOutput "💡 Por favor instala AWS CLI desde: https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2-windows.html" "Yellow"
    exit 1
}

# Verificar credenciales de AWS
try {
    $AccountInfo = aws sts get-caller-identity --output json 2>$null | ConvertFrom-Json
    $AccountID = $AccountInfo.Account
    Write-ColoredOutput "✅ AWS CLI configurado correctamente" "Green"
    Write-ColoredOutput "📊 Cuenta AWS: $AccountID" "Blue"
    Write-ColoredOutput "📍 Región: $AWSRegion" "Blue"
} catch {
    Write-ColoredOutput "❌ AWS CLI no está configurado correctamente" "Red"
    Write-ColoredOutput "💡 Por favor ejecuta: aws configure" "Yellow"
    exit 1
}

# Crear bucket S3
Write-ColoredOutput "🪣 Creando bucket S3: $BucketName" "Yellow"

try {
    $CreateBucketResult = aws s3 mb "s3://$BucketName" --region $AWSRegion 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-ColoredOutput "✅ Bucket S3 creado exitosamente" "Green"
    } else {
        throw "Error creando bucket: $CreateBucketResult"
    }
} catch {
    Write-ColoredOutput "❌ Error creando bucket S3: $_" "Red"
    exit 1
}

# Habilitar versionado en el bucket
Write-ColoredOutput "🔄 Habilitando versionado en el bucket..." "Yellow"
try {
    aws s3api put-bucket-versioning --bucket $BucketName --versioning-configuration Status=Enabled
    Write-ColoredOutput "✅ Versionado habilitado" "Green"
} catch {
    Write-ColoredOutput "⚠️  Advertencia: No se pudo habilitar el versionado" "Yellow"
}

# Habilitar encriptación en el bucket
Write-ColoredOutput "🔒 Habilitando encriptación en el bucket..." "Yellow"
try {
    $EncryptionConfig = @'
{
    "Rules": [
        {
            "ApplyServerSideEncryptionByDefault": {
                "SSEAlgorithm": "AES256"
            }
        }
    ]
}
'@
    
    $TempFile = [System.IO.Path]::GetTempFileName()
    $EncryptionConfig | Out-File -FilePath $TempFile -Encoding utf8
    aws s3api put-bucket-encryption --bucket $BucketName --server-side-encryption-configuration "file://$TempFile"
    Remove-Item $TempFile
    Write-ColoredOutput "✅ Encriptación habilitada" "Green"
} catch {
    Write-ColoredOutput "⚠️  Advertencia: No se pudo habilitar la encriptación" "Yellow"
}

# Bloquear acceso público
Write-ColoredOutput "🛡️  Bloqueando acceso público al bucket..." "Yellow"
try {
    aws s3api put-public-access-block --bucket $BucketName --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
    Write-ColoredOutput "✅ Acceso público bloqueado" "Green"
} catch {
    Write-ColoredOutput "⚠️  Advertencia: No se pudo bloquear el acceso público" "Yellow"
}

# Crear tabla DynamoDB
Write-ColoredOutput "🗄️  Creando tabla DynamoDB: $DynamoDBTable" "Yellow"

try {
    $CreateTableResult = aws dynamodb create-table --table-name $DynamoDBTable --attribute-definitions AttributeName=LockID,AttributeType=S --key-schema AttributeName=LockID,KeyType=HASH --provisioned-throughput ReadCapacityUnits=1,WriteCapacityUnits=1 --region $AWSRegion 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-ColoredOutput "✅ Tabla DynamoDB creada exitosamente" "Green"
    } else {
        Write-ColoredOutput "❌ Error creando tabla DynamoDB (puede que ya exista)" "Red"
    }
} catch {
    Write-ColoredOutput "❌ Error creando tabla DynamoDB: $_" "Red"
}

# Esperar a que la tabla esté activa
Write-ColoredOutput "⏳ Esperando a que la tabla DynamoDB esté activa..." "Yellow"
try {
    aws dynamodb wait table-exists --table-name $DynamoDBTable --region $AWSRegion
    Write-ColoredOutput "✅ Tabla DynamoDB activa" "Green"
} catch {
    Write-ColoredOutput "⚠️  Advertencia: No se pudo verificar el estado de la tabla" "Yellow"
}

# Actualizar main.tf con el nombre del bucket
Write-ColoredOutput "📝 Actualizando main.tf con el nuevo bucket..." "Yellow"

if (Test-Path "main.tf") {
    try {
        # Crear backup del archivo original
        Copy-Item "main.tf" "main.tf.backup" -Force
        
        # Leer el contenido del archivo
        $Content = Get-Content "main.tf" -Raw
        
        # Actualizar el nombre del bucket usando expresión regular
        $UpdatedContent = $Content -replace 'bucket\s*=\s*"[^"]*"', "bucket         = `"$BucketName`""
        
        # Escribir el contenido actualizado
        $UpdatedContent | Set-Content "main.tf" -NoNewline
        
        Write-ColoredOutput "✅ main.tf actualizado" "Green"
    } catch {
        Write-ColoredOutput "⚠️  Error actualizando main.tf: $_" "Yellow"
        Write-ColoredOutput "💡 Por favor actualiza manualmente el nombre del bucket en main.tf" "Yellow"
    }
} else {
    Write-ColoredOutput "⚠️  Archivo main.tf no encontrado en el directorio actual" "Yellow"
    Write-ColoredOutput "💡 Por favor actualiza manualmente el nombre del bucket en main.tf" "Yellow"
}

# Mostrar resumen
Write-ColoredOutput "=================================================" "Blue"
Write-ColoredOutput "🎉 ¡Configuración completada exitosamente!" "Green"
Write-ColoredOutput "=================================================" "Blue"
Write-ColoredOutput "📋 Información del backend:" "Yellow"
Write-ColoredOutput "   🪣 Bucket S3: $BucketName" "White"
Write-ColoredOutput "   🗄️  Tabla DynamoDB: $DynamoDBTable" "White"
Write-ColoredOutput "   📍 Región: $AWSRegion" "White"
Write-ColoredOutput "" "White"
Write-ColoredOutput "📝 Variables para GitLab CI/CD:" "Yellow"
Write-ColoredOutput "   TF_STATE_BUCKET: $BucketName" "White"
Write-ColoredOutput "   TF_STATE_KEY: openwebui/infra/terraform.tfstate" "White"
Write-ColoredOutput "   TF_DYNAMODB_TABLE: $DynamoDBTable" "White"
Write-ColoredOutput "   AWS_DEFAULT_REGION: $AWSRegion" "White"
Write-ColoredOutput "" "White"
Write-ColoredOutput "🔐 No olvides configurar en GitLab CI/CD Variables:" "Yellow"
Write-ColoredOutput "   AWS_ACCESS_KEY_ID: tu_access_key" "White"
Write-ColoredOutput "   AWS_SECRET_ACCESS_KEY: tu_secret_key" "White"
Write-ColoredOutput "" "White"
Write-ColoredOutput "✨ Ya puedes ejecutar: terraform init" "Green"
