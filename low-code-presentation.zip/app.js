class PresentationController {
    constructor() {
        this.currentSlide = 1;
        this.totalSlides = 12;
        this.slidesContainer = document.getElementById('slidesContainer');
        this.slides = document.querySelectorAll('.slide');
        this.prevBtn = document.getElementById('prevBtn');
        this.nextBtn = document.getElementById('nextBtn');
        this.currentSlideSpan = document.getElementById('currentSlide');
        this.totalSlidesSpan = document.getElementById('totalSlides');
        this.progressFill = document.querySelector('.progress-fill');

        this.init();
    }

    init() {
        // Set initial state
        this.updateSlideDisplay();
        this.updateProgressBar();
        this.updateNavigationButtons();
        
        // Set total slides
        this.totalSlidesSpan.textContent = this.totalSlides;

        // Add event listeners
        this.prevBtn.addEventListener('click', () => this.previousSlide());
        this.nextBtn.addEventListener('click', () => this.nextSlide());
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeyNavigation(e));

        // Touch/swipe support for mobile
        this.addTouchSupport();
    }

    nextSlide() {
        if (this.currentSlide < this.totalSlides) {
            this.currentSlide++;
            this.updateSlideDisplay();
            this.updateProgressBar();
            this.updateNavigationButtons();
            this.animateSlideTransition('next');
        }
    }

    previousSlide() {
        if (this.currentSlide > 1) {
            this.currentSlide--;
            this.updateSlideDisplay();
            this.updateProgressBar();
            this.updateNavigationButtons();
            this.animateSlideTransition('prev');
        }
    }

    goToSlide(slideNumber) {
        if (slideNumber >= 1 && slideNumber <= this.totalSlides && slideNumber !== this.currentSlide) {
            const direction = slideNumber > this.currentSlide ? 'next' : 'prev';
            this.currentSlide = slideNumber;
            this.updateSlideDisplay();
            this.updateProgressBar();
            this.updateNavigationButtons();
            this.animateSlideTransition(direction);
        }
    }

    updateSlideDisplay() {
        // Hide all slides
        this.slides.forEach(slide => {
            slide.classList.remove('active');
        });

        // Show current slide
        const currentSlideElement = document.querySelector(`[data-slide="${this.currentSlide}"]`);
        if (currentSlideElement) {
            currentSlideElement.classList.add('active');
        }

        // Update counter
        this.currentSlideSpan.textContent = this.currentSlide;
    }

    updateProgressBar() {
        const progressPercentage = (this.currentSlide / this.totalSlides) * 100;
        this.progressFill.style.width = `${progressPercentage}%`;
    }

    updateNavigationButtons() {
        // Update previous button
        this.prevBtn.disabled = this.currentSlide === 1;
        
        // Update next button
        this.nextBtn.disabled = this.currentSlide === this.totalSlides;
    }

    animateSlideTransition(direction) {
        const currentSlideElement = document.querySelector(`[data-slide="${this.currentSlide}"]`);
        
        if (currentSlideElement) {
            // Add entrance animation class
            currentSlideElement.classList.add('slide-enter');
            
            // Remove animation class after animation completes
            setTimeout(() => {
                currentSlideElement.classList.remove('slide-enter');
            }, 300);
        }
    }

    handleKeyNavigation(e) {
        switch (e.key) {
            case 'ArrowRight':
            case ' ': // Spacebar
                e.preventDefault();
                this.nextSlide();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                this.previousSlide();
                break;
            case 'Home':
                e.preventDefault();
                this.goToSlide(1);
                break;
            case 'End':
                e.preventDefault();
                this.goToSlide(this.totalSlides);
                break;
            case 'Escape':
                e.preventDefault();
                this.toggleFullscreen();
                break;
            default:
                // Handle number keys for direct slide navigation
                if (e.key >= '1' && e.key <= '9') {
                    const slideNum = parseInt(e.key);
                    if (slideNum <= this.totalSlides) {
                        e.preventDefault();
                        this.goToSlide(slideNum);
                    }
                }
                break;
        }
    }

    addTouchSupport() {
        let touchStartX = 0;
        let touchEndX = 0;
        let touchStartY = 0;
        let touchEndY = 0;

        this.slidesContainer.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
        });

        this.slidesContainer.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            touchEndY = e.changedTouches[0].screenY;
            this.handleSwipe(touchStartX, touchEndX, touchStartY, touchEndY);
        });
    }

    handleSwipe(startX, endX, startY, endY) {
        const deltaX = endX - startX;
        const deltaY = endY - startY;
        const minSwipeDistance = 50;

        // Check if horizontal swipe is dominant
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > minSwipeDistance) {
            if (deltaX > 0) {
                // Swipe right - previous slide
                this.previousSlide();
            } else {
                // Swipe left - next slide
                this.nextSlide();
            }
        }
    }

    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                console.log('Error attempting to enable fullscreen:', err);
            });
        } else {
            document.exitFullscreen().catch(err => {
                console.log('Error attempting to exit fullscreen:', err);
            });
        }
    }

    // Method to programmatically trigger animations on specific slides
    triggerSlideAnimations() {
        const currentSlideElement = document.querySelector(`[data-slide="${this.currentSlide}"]`);
        
        if (!currentSlideElement) return;

        // Add specific animations based on slide content
        switch (this.currentSlide) {
            case 3: // Architecture layers
                this.animateArchitectureLayers();
                break;
            case 4: // Principles
                this.animatePrincipleCards();
                break;
            case 8: // Infrastructure
                this.animateEnvironmentFlow();
                break;
            case 11: // Roadmap
                this.animateRoadmapPhases();
                break;
        }
    }

    animateArchitectureLayers() {
        const layers = document.querySelectorAll('.layer');
        layers.forEach((layer, index) => {
            setTimeout(() => {
                layer.style.transform = 'translateX(0)';
                layer.style.opacity = '1';
            }, index * 200);
        });
    }

    animatePrincipleCards() {
        const cards = document.querySelectorAll('.principle-card');
        cards.forEach((card, index) => {
            setTimeout(() => {
                card.style.transform = 'translateY(0) scale(1)';
                card.style.opacity = '1';
            }, index * 150);
        });
    }

    animateEnvironmentFlow() {
        const environments = document.querySelectorAll('.environment');
        environments.forEach((env, index) => {
            setTimeout(() => {
                env.style.transform = 'scale(1)';
                env.style.opacity = '1';
            }, index * 300);
        });
    }

    animateRoadmapPhases() {
        const phases = document.querySelectorAll('.phase');
        phases.forEach((phase, index) => {
            setTimeout(() => {
                phase.style.transform = 'translateY(0)';
                phase.style.opacity = '1';
            }, index * 200);
        });
    }

    // Utility methods
    getCurrentSlideData() {
        return {
            current: this.currentSlide,
            total: this.totalSlides,
            progress: (this.currentSlide / this.totalSlides) * 100
        };
    }

    // Method to add custom interactions for specific slides
    addSlideInteractions() {
        // Add click interactions for principle cards
        document.querySelectorAll('.principle-card').forEach(card => {
            card.addEventListener('click', () => {
                card.classList.toggle('expanded');
            });
        });

        // Add hover effects for architecture layers
        document.querySelectorAll('.layer').forEach(layer => {
            layer.addEventListener('mouseenter', () => {
                layer.style.transform = 'translateX(12px) scale(1.02)';
            });
            
            layer.addEventListener('mouseleave', () => {
                layer.style.transform = 'translateX(0) scale(1)';
            });
        });

        // Add click interaction for governance controls
        document.querySelectorAll('.control').forEach(control => {
            control.addEventListener('click', () => {
                control.style.background = 'var(--color-primary)';
                control.style.color = 'var(--color-btn-primary-text)';
                
                setTimeout(() => {
                    control.style.background = '';
                    control.style.color = '';
                }, 1000);
            });
        });
    }
}

// Additional utility functions
function createSlideIndicators() {
    const navigation = document.querySelector('.navigation');
    const indicators = document.createElement('div');
    indicators.className = 'slide-indicators';
    
    for (let i = 1; i <= 12; i++) {
        const indicator = document.createElement('button');
        indicator.className = 'indicator';
        indicator.setAttribute('data-slide', i);
        indicator.setAttribute('aria-label', `Ir a slide ${i}`);
        
        if (i === 1) {
            indicator.classList.add('active');
        }
        
        indicator.addEventListener('click', () => {
            presentation.goToSlide(i);
            updateIndicators(i);
        });
        
        indicators.appendChild(indicator);
    }
    
    // Insert indicators before the counter
    navigation.insertBefore(indicators, document.querySelector('.slide-counter'));
}

function updateIndicators(activeSlide) {
    document.querySelectorAll('.indicator').forEach((indicator, index) => {
        indicator.classList.toggle('active', index + 1 === activeSlide);
    });
}

// Initialize presentation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize main presentation controller
    window.presentation = new PresentationController();
    
    // Add slide interactions
    presentation.addSlideInteractions();
    
    // Create and add slide indicators (optional)
    // createSlideIndicators();
    
    // Add focus management for accessibility
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
            // Ensure focus stays within current slide
            const currentSlide = document.querySelector('.slide.active');
            const focusableElements = currentSlide.querySelectorAll(
                'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
            );
            
            if (focusableElements.length === 0) {
                e.preventDefault();
            }
        }
    });
    
    // Add window resize handler for responsive adjustments
    window.addEventListener('resize', () => {
        // Recalculate any dynamic layouts if needed
        presentation.updateSlideDisplay();
    });
    
    // Add visibility change handler to pause/resume animations
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            // Pause any running animations
            document.body.classList.add('paused');
        } else {
            // Resume animations
            document.body.classList.remove('paused');
            presentation.triggerSlideAnimations();
        }
    });

    // Add print support
    window.addEventListener('beforeprint', () => {
        // Show all slides for printing
        document.querySelectorAll('.slide').forEach(slide => {
            slide.style.display = 'block';
            slide.style.pageBreakAfter = 'always';
        });
    });

    window.addEventListener('afterprint', () => {
        // Restore normal display
        presentation.updateSlideDisplay();
    });

    // Console helper for development
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('🎯 Presentación ITAÚ Low Code Platform cargada');
        console.log('📋 Comandos disponibles:');
        console.log('  • Flechas ← → para navegar');
        console.log('  • Números 1-9 para ir directamente a slide');
        console.log('  • Espaciador para avanzar');
        console.log('  • Escape para toggle fullscreen');
        console.log('  • presentation.goToSlide(n) desde consola');
        
        // Make presentation object globally accessible for debugging
        window.p = presentation;
    }
});